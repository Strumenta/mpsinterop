Component Dependencies - an MPS diagramming demo
================================================

A sample project illustrating the MPS diagramming support. Open the project, open any of the sample diagrams
in the "jetbrains.mps.samples.componentDependencies.sandbox" solution, right-click in the editor area and choose the "diagram" hint
in the "Push Editor Hints" pop-up menu.

