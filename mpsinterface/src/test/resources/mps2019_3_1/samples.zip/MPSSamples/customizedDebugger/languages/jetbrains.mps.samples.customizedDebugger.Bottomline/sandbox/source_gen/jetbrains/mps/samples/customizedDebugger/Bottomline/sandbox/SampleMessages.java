package jetbrains.mps.samples.customizedDebugger.Bottomline.sandbox;
class SampleMessages {

  public static void main(String[] args) {

    System.out.println("Hello");

    System.out.println("Hi");

    System.out.println("Good morning!");
  }
}