package jetbrains.mps.samples.customizedDebugger.Highlevel.sandbox.model;
class MorningChitChat {

  public static void main(String[] args) {

    System.out.println("Joe says: Good morning!");

    System.out.println("Alice says: Hi Joe!");

    System.out.println("Brian says: Hi there!");

    System.out.println("Joe says: What's up today?");

    System.out.println("Alice says: We'll be testing custom MPS debugger after lunch.");

    System.out.println("Joe says: That sounds useful. Are you, Brian, joining us?");

    System.out.println("Brian says: Of course, I am! Can't miss that!");
  }
}