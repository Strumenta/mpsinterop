﻿Generator and TextGen Attributes

================================


This sample shows few scenarios handling NodeAttributes in generators and text transformations.